import React, { useState } from "react";
import * as XLSX from "xlsx/xlsx.mjs";

const ExcelImport = (props) => {
  const [file, setFile] = useState([]);
  const [fileName, setFileName] = useState(null);
  const [sheetNames, setSheetNames] = useState(null);
  const [sheetData, setSheetData] = useState({});

  const readDataFromExcel = (data) => {
    const wb = XLSX.read(data);

    setSheetNames(wb.SheetNames);

    var mySheetData = {};

    //looping thru objects

    for (var i = 0; i < wb.SheetNames.length; i++) {
      let sheetName = wb.SheetNames[i];
      const worksheet = wb.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, {
        blankrows: "",
        headers: 1,
      });
      mySheetData[sheetName] = jsonData;
      console.log(sheetName);
    }
    setSheetData(mySheetData);
    return mySheetData;
  };

  const handleFile = async (e) => {
    const myFile = e.target.files[0];
    if (!myFile) return;
    setFileName(myFile);
    console.log(e);
    const data = await myFile.arrayBuffer();
    const mySheetData = readDataFromExcel(data);
    setFile(myFile);
    props.onFileUploaded(mySheetData);
  };

  return (
    <>
      <input
        type="file"
        accept="xlsx,xls"
        multiple={false}
        onChange={handleFile}
      />
    </>
  );
};

export default ExcelImport;
